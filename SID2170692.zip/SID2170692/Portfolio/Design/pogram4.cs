using System;

namespace Design_project
{

    class Program
    {
        static void Main(string[] args)
        {

            string user_input1, user_input2;
            double height, breadth, Area_of_window, woodlenght, woodLenght_Inch;


            Console.WriteLine("Enter proposed window height: ");   //get window height
            user_input1 = Console.ReadLine();
            height = double.Parse(user_input1);
            Console.WriteLine("Enter proposed window breadth: ");
            //get window breadth
            user_input2 = Console.ReadLine();
            breadth = double.Parse(user_input2);

            Console.WriteLine();
            //get window area
            Area_of_window = height * breadth;

            woodlenght = WindowRequirement.convert_feet(height, breadth);
            woodLenght_Inch = WindowRequirement.convert_inches(height, breadth);



            if ((breadth >= 0.5 && breadth <= 3.5) && (height >= 0.5 && height <= 2))
            {
                Console.WriteLine($"The amount of glass needed is: {Area_of_window} sqm \nThe amount of wood needed is: {woodlenght} feet {woodLenght_Inch} inches");
            }
            else
            {
                Console.WriteLine("Please stay within limits of 0.5 & 3.5 for breadth and 0.5 and 2.0 for height");
            }


            Console.ReadKey();

        }
        class WindowRequirement
        {
           static public double convert_feet(double width, double height) //Convert meters to feet
            {
                double length;
                length = 2 * (width + height) * 3.25;
                double trunc = Math.Truncate(length);

                return trunc;
            }
            static public double convert_inches(double f, double T)   //method to convert to inches
            {
                double Inch;
                Inch = (2.0 * (f + T) * (3.25 * 12)) % 12;
                return Inch;

            }
        }

    }
}