//learning loops assignment

using System;

namespace loops_project {
 //declear static class
 static void Main(string[] args) {
    
    //initializing the array
    int [] numbers_given = { 15, 68, 4, 19, 99, 52, 53, 36, 74, 1, 85 };

    int num;

    //loop through array and print contents on single line sepearated by space

      for (int i = 0; i < numbers_given.Length; i++) {
         Console.Write(numbers_given[i] + " ");
      }
      Console.WriteLine();
      Console.WriteLine();

      //loop through array and print even numbers on single line sepearated by space

      for (int i = 0; i < numbers_given.Length; i++) {
         if (numbers_given[i] % 2 == 0) {
            Console.Write(numbers_given[i] + " ");
         }
      }
      Console.WriteLine();

      //loop through array and print odd numbers on single line sepearated by space

      for (int i = 0; i < numbers_given.Length; i++) {
         if (numbers_given[i] % 2 != 0) {
            Console.Write(numbers_given[i] + " ");
         }
      }
      Console.WriteLine();
       Console.ReadKey();

    

    
 }
}