﻿using System;

namespace Inheritance
{
    class Employee
    {
        protected string name; //holds name of employee
        protected string id; //hold employee id


        public Employee(string em_name, string em_id)
        {
            name = em_name;
            id = em_id;

        }
        public void display()
        {
            Console.WriteLine("Welcome to your employee portal .");
            Console.WriteLine($"\n Name of Residential Engineer: { name} \nEmployee ID: { id}");
        }

    }


    class Secretary : Employee
    {

        private int wpm; // holds words per minute

        public Secretary(string n, string i, int wpm1) : base(n, i)
        {
            wpm = wpm1;
        }
        public void display()
        {
            Console.WriteLine("Executive Department");
            Console.WriteLine($"Secretary Name: {name} \nID: {id} \nWPM: {wpm}");
        }


    }

    class Programmer : Employee
    {

        private string lang; // VAR holds preferred language

        public Programmer(string n, string i, string codeLanguage) : base(n, i)
        {
            lang = codeLanguage;
        }
        public void display()
        {
            Console.WriteLine("IT Department ");
            Console.WriteLine($"Programmer Name: {name} \nID: {id} \nPreferred Language: {lang} ");
        }
    }

    class Engineer : Employee
    {

        private string os; // variable holds preferred operating system

        public Engineer(string n, string i, string osType) : base(n, i)
        {
            os = osType;
        }
        public void display()
        {
            Console.WriteLine("IT Department ");
            Console.WriteLine($"Engineer Name: {name} \nID: {id} \nPreferred Operating Sytem: {os}");
        }

    }

    class Data
    {
        public static void Main(string[] args)
        {

            Employee emp = new Employee("Megan", "MNG8954r");
            emp.display();

            Console.WriteLine();

            Secretary sec = new Secretary("Paige", "SEC559791", 59);
            sec.display();

            Console.WriteLine();

            Programmer prog = new Programmer("Smith", "PRO20328886", "Ruby");
            prog.display();

            Console.WriteLine();

            Engineer eng = new Engineer("Josh", "ENG74778", "macOS");
            eng.display();

            Console.WriteLine();

            Engineer eng1 = new Engineer("Jaemally", "ENG0222", "Linux");
            eng1.display();

            Console.ReadKey();
        }

    }
}