﻿using System;

namespace GetandSet
{
    class TestProgram
    {
        public static void Main(string[] args)
        {
            Module Engineering = new Module();

            Module Archeology = new Module(40, 60, 0.7);

            Engineering.setData(50, 70, 0.6);

            Console.WriteLine($"Your coursework score for General Studies is: {Archeology.getCw()} " +
                $"\nYour Exam score for General Studies is: {Archeology.getEx()} " +
                $"\nYour final mark for General Studies is {TestProgram.finalMark(Archeology)}");

            Console.WriteLine();

            Console.WriteLine($"Your coursework score for Micro-Biology is: {Engineering.getCw()} " +
                $"\nYour Exam score for  Micro-Biology is: {Engineering.getEx()} " +
                $"\nYour final mark for  Micro-Biology is {TestProgram.finalMark(Engineering)}");

            Console.ReadLine();

        }
        public static int finalMark(Module subject)
        {
            double mark;
            double coursework = subject.getCw();
            double exam = subject.getEx();

            mark = coursework * (1.0 * subject.getExwt()) + exam * subject.getExwt();


            return (int)mark;

        }
    }
    class Module
    {
        private int coursework;
        private int exam;
        private double examweighting;

        public Module()
        {
            this.coursework = 0;
            exam = 0;
            examweighting = 0.0;
        }
        public Module(int cw, int ex, double exwt)
        {
            coursework = cw;
            exam = ex;
            examweighting = exwt;

        }
        public int getCw()
        {
            return this.coursework;
        }
        public int getEx()
        {
            {
                return this.exam;
            }
        }
        public double getExwt()
        {
            {
                return this.examweighting;
            }
        }
        public void setData(int cw, int ex, double exwt)
        {
            coursework = cw;
            exam = ex;
            examweighting = exwt;
        }
    }

}