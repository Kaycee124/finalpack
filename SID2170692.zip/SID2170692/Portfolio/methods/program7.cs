﻿using System;


namespace methodsLessons
{
    class TempConverter
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            double farenheit, celsius;
            Console.WriteLine("Enter a temperature in degrees F >");        //Collect temperature in farenheit
            farenheit = double.Parse(Console.ReadLine());
            celsius = TempConv.calcTempC(farenheit);
            TempConv.dislayTempC(celsius);
            
        }
        
        static double calcTempC(double farenheit)            //farenheirt to celcius
            double result;
            result = (farenheit - 32.0) * 5.0 / 9.0;
            return result;
        }
        static void dislayTempC(double celsius)                //display temperature in celcius
        {
            Console.WriteLine ( $"Your temperature in celsius is {celsius}");
            Console.ReadLine();
        
        }


    }
   
    
    
}

