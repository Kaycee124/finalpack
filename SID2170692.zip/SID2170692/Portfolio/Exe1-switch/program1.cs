using System;

namespace Switch_project
{
    class Program
    {
        static void Main(string[] args)
        {
            //get student name and id
            String StudentName;
            Console.WriteLine("Enter your Name: ");

            StudentName = Console.ReadLine();

            Console.WriteLine();

            Console.Write($"Hello {StudentName}, \nWelcome to your grade portal.");

            String StudentID;
            Console.WriteLine("Enter your StudentID: ");

            StudentID = Console.ReadLine();

            Console.WriteLine();

            Console.Write($" Your Student ID {StudentID},.");

            Console.WriteLine();
            char Grade = 'A';
            Console.WriteLine("\nEnter your grade: ");      //request grade
            Grade = Console.ReadLine().ToCharArray()[0];


            string result = " ";
            switch (Grade)
            {
                case 'A':
                    result = "70 - 100";
                    break;
                case 'B':
                    result = "60 - 69";
                    break;
                case 'C':
                    result = "50 - 59";
                    break;
                case 'D':
                    result = "40 - 49";
                    break;
                case 'F':
                    result = "0 - 39";
                    break;
                default:
                    result = "not available.";
                    Console.WriteLine("This academic grade does not exist yet!");
                    break;
            }
            Console.WriteLine($"For Grade {Grade} you need {result} to get this grade.");
            Console.ReadKey();


        }
    }
}