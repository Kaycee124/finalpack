﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Objects

{
    class CountryTest
    {
        public static void Main(string[] args)
        {
            Country name1 = new Country("UK", 59000000, 245000.0);
           
            Country name2 = new Country(" China", 1330000000, 9600000.0);
            
            Country name3 = new Country("Malawi", 50000, 118000.0);

            Console.WriteLine($"Country Name: {name1.name} \nPopultion size: {name1.size} \nArea: {name1.area}");
            Console.WriteLine();
            Console.WriteLine($"Country Name: {name2.name} \nPopultion size: {name2.size} \nArea: {name2.area}");
            Console.WriteLine();
            Console.WriteLine($"Country Name: {name3.name} \nPopultion size: {name3.size} \nArea: {name3.area}");

            Console.ReadLine();

        }

    }

    class Country
    {
        public string name;
        public int size;
        public double area;
        public Country(string input, int input2, double input3)
        {
            name = input;
            size = input2;
            area = input3;

        }

    }

       
}